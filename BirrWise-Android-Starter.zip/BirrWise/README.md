# BirrWise (MVP starter)

A privacy-first Android expense tracker starter for Ethiopian birr (ETB).

## Current scope
- Kotlin + Jetpack Compose UI
- Manual income/expense entry (demo state resets when app restarts)
- Transaction list and month-to-date totals
- Simple category budgets (starter limits)
- No accounts, server, analytics, persistent database, or SMS permission in this first build

## Important
This first prototype keeps transactions in memory only. The next implementation step is persistent local storage (Room), followed by SMS parsing and statement import.

This is a starter source project, not yet a tested APK. Android Studio/Gradle is needed to compile and run it.
Automatic SMS parsing and CSV/PDF statement import are intentionally not enabled until the manual ledger is working and the relevant bank message/statement formats can be tested. SMS permission is sensitive; add it only with a clear user-controlled permission flow.

## Open
1. Install Android Studio.
2. Open this folder as a project.
3. Let Gradle sync.
4. Run the `app` configuration on an Android device or emulator.

Package: `et.birrwise.app`
Minimum SDK: 26 (Android 8.0)
