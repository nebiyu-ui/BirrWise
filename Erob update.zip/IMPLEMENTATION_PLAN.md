# Implementation plan

A phase counts as done only when it compiles, its tests pass, and the GitHub Actions build is green.

| Phase | Scope | Status |
|---|---|---|
| 1 | Repository stabilization: working build and installable debug APK | Done |
| 2 | App foundation: theme, five-section navigation, empty screens | Done (checked on a phone) |
| 3a | Financial calculation engine: money, periods, balances, reports, budget math, with tests | In progress (waiting for build result) |
| 3b | Room database: entities, DAOs, repositories, migrations, database tests | Planned |
| 4 | Accounts and manual transactions | Planned |
| 5 | Home overview, transaction history, search, filters | Planned |
| 6 | Categories and monthly budgets | Planned |
| 7 | CSV import and export, duplicate detection | Planned |
| 8 | SMS message parsing | Planned |
| 9 | PDF statements and account reconciliation | Planned |
| 10 | Savings goals, recurring transactions, reports, People section | Planned |
| 11 | Amharic localization and polish | Planned |
| 12 | Security and release testing | Planned |

## Required financial tests not covered yet

- Duplicate imports do not change balances: needs duplicate detection (Phase 7).
- Editing a transaction updates every affected summary: needs the database (Phase 3b).
- Persistence after the app restarts, foreign keys, and migrations: Phase 3b.

## Notes

- The calculation rules are written down in `docs/FINANCIAL_RULES.md`.
- The People section lists people who often appear in transactions. It needs the database before it can show anything.
- Reports move to a Reports screen opened from Home.
