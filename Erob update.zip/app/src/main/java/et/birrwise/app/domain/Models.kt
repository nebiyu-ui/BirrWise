package et.birrwise.app.domain

import java.time.Instant

/**
 * What a transaction is. Amounts are always positive; the type decides the financial effect.
 * A transfer between two accounts is recorded as two linked legs (TRANSFER_OUT and TRANSFER_IN)
 * that share a transferGroupId.
 */
enum class TransactionType {
    INCOME,
    EXPENSE,
    FEE,
    REFUND,
    TRANSFER_IN,
    TRANSFER_OUT,
    REVERSAL
}

enum class TransactionStatus {
    CONFIRMED,
    PENDING_REVIEW
}

/**
 * The opening balance is the account's balance at [openingBalanceDate], before any transaction
 * that happens at or after that moment. Transactions before that moment are already part of the
 * opening balance and are not counted again. If the date is null, every transaction counts.
 */
data class Account(
    val id: String,
    val name: String,
    val currencyCode: String,
    val openingBalance: Money,
    val openingBalanceDate: Instant? = null
) {
    init {
        require(id.isNotBlank()) { "Account id must not be blank" }
        require(openingBalance.currencyCode == currencyCode) {
            "Opening balance currency ${openingBalance.currencyCode} does not match account currency $currencyCode"
        }
    }
}

data class Transaction(
    val id: String,
    val accountId: String,
    val type: TransactionType,
    val amount: Money,
    val occurredAt: Instant,
    val categoryId: String? = null,
    val status: TransactionStatus = TransactionStatus.CONFIRMED,
    val transferGroupId: String? = null,
    val reversesTransactionId: String? = null,
    val isExcludedFromReports: Boolean = false
) {
    init {
        require(id.isNotBlank()) { "Transaction id must not be blank" }
        require(accountId.isNotBlank()) { "Account id must not be blank" }
        require(amount.minorUnits > 0L) { "Transaction amounts must be greater than zero" }
    }
}
